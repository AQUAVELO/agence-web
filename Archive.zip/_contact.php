<header class="main-header clearfix">
  <div class="container">
    <h1 class="page-title pull-left">Contactez-nous</h1>

    <ol class="breadcrumb pull-right">
      <li><a href="./">Accueil</a></li>
      <li class="active">Contact</li>
    </ol>
  </div>
</header>

<section class="content-area bg1">
  <div class="container">

    <header class="page-header text-center">
      <h1 class="page-title">Besoin d'aide</h1>

      <h2>Nous aimons avoir votre avis</h2>

      <p class="larger">Vous avez une question ou souhaitez contacter l'un de nos centres? Utilisez le formulaire ci-dessous ou envoyez-nous un e-mail à <a href="mailto:info@aquavelo.com">info@aquavelo.com</a>.</p>
    </header>

    <div class="row">
      <div class="col-md-8">
        <div class="contactForm">
          <div class="successMessage alert alert-success alert-dismissable" style="display: none">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            Merci! Nous vous répondrons dès que possible.
          </div>
          <div class="errorMessage alert alert-danger alert-dismissable" style="display: none">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            Une erreur est survenue.
          </div>

          <form class="liveForm" role="form" action="/form/send.php" method="post" data-email-subject="Contact Form" data-show-errors="true" data-hide-form="false">
            <fieldset>
              <div class="row">
                <div class="col-md-6">
                  <div class="form-group">
                    <label class="control-label">Nom <span>(obligatoire)</span></label>
                    <input type="text" required name="field[]" class="form-control">
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label class="control-label">E-mail <span>(obligatoire)</span></label>
                    <input type="email" required name="field[]" class="form-control">
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-12">
                  <div class="form-group">
                    <label class="control-label">Sujet</label>
                    <input type="text" name="field[]" class="form-control">
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-12">
                  <div class="form-group">
                    <label class="control-label">Message <span>(obligatoire)</span></label>
                    <textarea name="field[]" required class="form-control" rows="5"></textarea>
                  </div>
                </div>
              </div>
              <input type="submit" class="btn btn-primary" value="Envoyer mon message">
            </fieldset>
          </form>
        </div>
      </div>
      <div class="col-md-4">

        <dl>
          <dt>Service clients</dt>
          <dd>46, Boulevard de l'Hôpital</dd>
          <dd>75013 Paris</dd>

          <dt>Téléphone</dt>
          <dd>+33 (0)6 27 50 33 08</dd>

          <dt>E-mail</dt>
          <dd><a href="mailto:info@aquavelo.com">info@aquavelo.com</a></dd>
        </dl>


      </div>
    </div>

  </div>
</section>

<section class="content-area bg2" data-topspace="0" data-btmspace="0">
  <div class="mapOuter">
    <div class="googleMap" data-location="46, Boulevard de l'Hôpital, 75013, Paris" data-height="410" data-offset="0"></div>
  </div>
</section>
