<? include'_slider.php'; ?>
 <section class="content-area bg1">
    <div class="container">
      <div class="row">
        <div class="col-md-4">
          <div class="iconBox">
            <div class="media"> <a class="pull-left" href="#"> <span class="octagon"> <span class="svg-load"></span> <i class="fa fa-calendar"></i> </span> </a>
              <div class="media-body">
                <h4 class="media-heading"><a href="#">R&eacute;servation en ligne</a></h4>
                <p>Avec 70 cours par semaine à votre disposition, réservez en ligne où que vous soyez, 
votre vélo vous attend selon votre emploi du temps. Pas de stress! </p>
              </div>
            </div>
          </div>
          <!-- / iconBox --> 
        </div>
        <div class="col-md-4">
          <div class="iconBox">
            <div class="media"> <a class="pull-left" href="#"> <span class="octagon"> <span class="svg-load"></span> <i class="fa fa-male"></i> </span> </a>
              <div class="media-body">
                <h4 class="media-heading"><a href="#">Coach sportif</a></h4>
                <p> Sélectionnés avec le plus grand soin, nos coachs diplômés vous motiveront à travers des chorégraphies rythmées pour atteindre rapidement vos objectifs.</p>
              </div>
            </div>
          </div>
          <!-- / iconBox --> 
        </div>
        <div class="col-md-4">
          <div class="iconBox">
            <div class="media"> <a class="pull-left" href="#"> <span class="octagon"> <span class="svg-load"></span> <i class="fa fa-users"></i> </span> </a>
              <div class="media-body">
                <h4 class="media-heading"><a href="#">Cours collectifs</a></h4>
                <p>Votre cours d'aquabiking dure 30 ou 45 minutes et se déroule en groupe restreint. Pourquoi ne pas proposer à un(e) ami(e) de vous accompagner ?</p>
              </div>
            </div>
          </div>
          <!-- / iconBox --> 
        </div>
      </div>
    </div>
  </section>
  <!-- / section -->
  
  <section class="content-area bg2">
    <div class="container">
      <header class="page-header text-center">
        <h1 class="page-title">Nos centres</h1>
        <h2>Localisez le centre le plus proche de chez vous</h2>
      </header>
      <div class="flexslider carousel-slider" data-slideshow="false" data-speed="7000" data-animspeed="600" data-loop="true" data-min="1" data-max="3" data-move="1" data-controls="true" data-dircontrols="true">
        <ul class="slides">
        <? while ($row_centers_last = $centers_last->fetch()) { 
		$department = $database->prepare('SELECT nom FROM departements WHERE id = ?');
	$department->execute(array($row_centers_last['department']));
	$row_department = $department->fetch();
	$department = $row_department['nom'];
		?>
          <li>
            <article class="portfolio-item animated" data-fx="fadeInUp">
              <div class="portfolio-thumbnail"> <a href="/centres/<?= $row_centers_last['city'] ?>"><img src="/images/content/works-01.jpg" alt=" "></a> <a href="/centres/<?= $row_centers_last['city'] ?>" class="overlay-img"><span class="overlay-ico"><i class="fa fa-plus"></i></span></a> </div>
              <div class="entry-meta"> <span class="cat-links"><a href="#"><?= $department; ?></a>, <a href="#"><?= $row_centers_last['country'] ?></a></span> </div>
              <h4 class="entry-title"><a href="#"><?= $row_centers_last['city'] ?>, <?= $row_centers_last['postal_code'] ?></a></h4>
            </article>
          </li>
          <? } ?>
          <li>
            <article class="portfolio-item animated" data-fx="fadeInDown">
              <div class="portfolio-thumbnail"> <a href="#"><img src="/images/content/works-02.jpg" alt=" "></a> <a href="#" class="overlay-img"><span class="overlay-ico"><i class="fa fa-plus"></i></span></a> </div>
              <div class="entry-meta"> <span class="cat-links"><a href="#">&Icirc;le de France</a>, <a href="#">France</a></span> </div>
              <h4 class="entry-title"><a href="#">Paris, 75013</a></h4>
            </article>
            <!-- / portfolio-item --> 
          </li>
          <li>
            <article class="portfolio-item animated" data-fx="fadeInUp">
              <div class="portfolio-thumbnail"> <a href="#"><img src="/images/content/works-03.jpg" alt=" "></a> <a href="#" class="overlay-img"><span class="overlay-ico"><i class="fa fa-plus"></i></span></a> </div>
              <div class="entry-meta"> <span class="cat-links"><a href="#">Maroc</a>, <a href="#">Afrique</a></span> </div>
              <h4 class="entry-title"><a href="#">Casablanca, Racine</a></h4>
            </article>
            <!-- / portfolio-item --> 
          </li>
        </ul>
      </div>
      <div class="text-center"> <a href="03-pluto-portfolio.html" class="btn btn-default animated" data-fx="fadeInUp">Tous les centres</a> </div>
    </div>
  </section>
  <!-- / section -->
  
  <section class="content-area bg1" data-btmspace="0">
    <div class="container">
      <div class="promoBox">
        <div class="row">
          <div class="col-md-6 col-md-push-6">
            <div class="inner animated" data-fx="fadeInLeft">
              <h2>Un design contemporain</h2>
              <p class="larger">Une alliance parfaite entre les matières minérales, l'eau, la pierre et le bois pour vous assurer un véritable hâvre de paix.<br> Qu’attendez-vous pour vous jeter à l'eau ?<br>
En pratiquant l'aquabiking, vous êtes immergé seulement jusqu’à la taille, vos cheveux restent secs. 
Une serviette et des produits de douche sont mis à votre disposition après chaque séance pour vous assurer confort et détente. </p>
              <a href="02-pluto-about.html" class="btn btn-default">Le concept</a> </div>
          </div>
          <div class="col-md-6 col-md-pull-6"> <img src="/images/content/home-v1-promo.jpg" alt=" " class="animated" data-fx="fadeInLeft"> </div>
        </div>
      </div>
      <!-- / promoBox --> 
    </div>
  </section>
  <!-- / section -->
  
  <section class="content-area brightText" data-bg="/images/content/home-v1-clients-bg.jpg">
    <div class="container">
      <header class="page-header text-center">
        <h1 class="page-title">Presse</h1>
        <h2>Ils ont test&eacute; et ils adorent !</h2>
      </header>
      <div class="row">
        <div class="col-md-8">
          <blockquote class="clearfix animated" data-fx="fadeInLeft">
            <div class="inner">
              <p class="larger"> Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis
                pretium. Integer tincidunt. Donec euismod vulputate porta. Mauris ultrices velit quis quam scelerisque luctus laoreet ac dui. Cras dapibus. </p>
            </div>
            <div class="media author"> <span class="pull-left"> <img class="media-object" src="/images/content/home-v1-clients-portrait.jpg" alt=" "> </span>
              <div class="media-body">
                <h4 class="media-heading">Rebecca Bowens <span>Manager @ Company Inc.</span> </h4>
              </div>
            </div>
          </blockquote>
        </div>
        <div class="col-md-4">
          <ul class="row thumbnails list-unstyled">
            <li class="col-xs-4 col-md-4"> <a href="#"> <img src="/images/content/home-v1-clients-logo1.png" alt=" " class="animated" data-fx="fadeInLeft"> </a> </li>
            <li class="col-xs-4 col-md-4"> <a href="#"> <img src="/images/content/home-v1-clients-logo2.png" alt=" " class="animated" data-fx="fadeInUp"> </a> </li>
            <li class="col-xs-4 col-md-4"> <a href="#"> <img src="/images/content/home-v1-clients-logo3.png" alt=" " class="animated" data-fx="fadeInRight"> </a> </li>
            <li class="col-xs-4 col-md-4"> <a href="#"> <img src="/images/content/home-v1-clients-logo4.png" alt=" " class="animated" data-fx="fadeInLeft"> </a> </li>
            <li class="col-xs-4 col-md-4"> <a href="#"> <img src="/images/content/home-v1-clients-logo5.png" alt=" " class="animated" data-fx="fadeInBottom"> </a> </li>
            <li class="col-xs-4 col-md-4"> <a href="#"> <img src="/images/content/home-v1-clients-logo6.png" alt=" " class="animated" data-fx="fadeInRight"> </a> </li>
          </ul>
          <!-- / thumbnails --> 
        </div>
      </div>
    </div>
  </section>
  <!-- / section -->
  
  <section class="content-area bg1">
    <div class="container">
      <div class="row">
        <div class="col-md-3 col-sm-6">
          <header class="page-header text-left animated" data-fx="flipInY">
            <h1 class="page-title">Actualit&eacute;s</h1>
            <h2>Derniers <br>
              &eacute;v&egrave;nements</h2>
            <a href="05-pluto-blog.html" class="btn btn-default">Toutes les actualit&eacute;s</a> </header>
        </div>
        <div class="col-md-3 col-sm-6">
          <article class="blog-item animated" data-fx="fadeInDown">
            <div class="blog-thumbnail"> <a href="#"><img src="/images/content/home-v1-blog-01.jpg" alt=" "></a> </div>
            <div class="entry-meta"> <span class="entry-date">December 3, 2013</span> <span class="entry-comments"><a href="#">1 comment</a></span> </div>
            <h4 class="entry-title"><a href="06-pluto-blog-single.html">This is a standard post format with preview picture</a></h4>
            <p> Asunt in anim uis aute irure dolor in reprehenderit in voluptate velit esse... </p>
          </article>
          <!-- / blog-item --> 
        </div>
        <div class="col-md-3 col-sm-6">
          <article class="blog-item animated" data-fx="fadeInUp">
            <div class="blog-thumbnail">
              <div class="flexslider std-slider center-controls" data-animation="fade" data-loop="true" data-animspeed="600" data-dircontrols="true">
                <ul class="slides">
                  <li><a href="#"><img src="/images/content/home-v1-blog-02.jpg" alt=" "></a></li>
                  <li><a href="#"><img src="/images/content/home-v1-blog-02-2.jpg" alt=" "></a></li>
                </ul>
              </div>
            </div>
            <div class="entry-meta"> <span class="entry-date">December 1, 2013</span> <span class="entry-comments"><a href="#">4 comment</a></span> </div>
            <h4 class="entry-title"><a href="#">Gallery post format: post with multiple images</a></h4>
            <p> Excepteur sint occaecat cupidatat non proident sunt in culpa qui deserunt... </p>
          </article>
          <!-- / blog-item --> 
        </div>
        <div class="col-md-3 col-sm-6">
          <article class="blog-item format-video animated" data-fx="fadeInDown">
            <div class="blog-thumbnail"> <a href="http://www.youtube.com/watch?v=HJ2F7eptn_A" class="popup-iframe"><img src="/images/content/home-v1-blog-03.jpg" alt=" "></a> </div>
            <div class="entry-meta"> <span class="entry-date">November 30, 2013</span> <span class="entry-comments"><a href="#">6 comment</a></span> </div>
            <h4 class="entry-title"><a href="#">This is a video post</a></h4>
            <p> Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit quia... </p>
          </article>
          <!-- / blog-item --> 
        </div>
      </div>
    </div>
  </section>
  <!-- / section -->
  