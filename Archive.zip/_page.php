

<header class="main-header clearfix">
  <div class="container">
    <h1 class="page-title pull-left">Aquabiking à <?php echo $city; ?>, <?= $row_center['postal_code']; ?>, <?php echo $department; ?>, <?php echo $region; ?></h1>

    <ol class="breadcrumb pull-right">
      <li><a href="./">Accueil</a></li>
      <li><a href="/centres">Centres</a></li>
      <li class="active"><?= $city; ?>, <?= $department; ?></li>
    </ol>
  </div>
</header>

<section class="content-area bg1">
  <div class="container">
    <div class="row">
      <div class="col-md-8">
        <img src="/images/content/project.jpg" alt=" ">
      </div>
      <div class="col-md-4">

        <dl>
          <dt>Adresse</dt>
          <dd><?= $row_center['address']; ?></dd>

          <dt>Téléphone</dt>
          <dd><?= $row_center['phone']; ?></dd>

          <dt>Horaires</dt>
          <dd><?= $row_center['openhours']; ?></dd>

          <dt>Web</dt>
          <dd><?= $row_center['website']; ?></dd>
        </dl>

        <p>
          <?= $row_center['description']; ?>
        </p>
        <br>
        <a href="#" class="btn btn-default">Réserver en ligne</a>

      </div>
    </div>

  </div>
</section>


<section class="content-area bg2">
  <div class="container">

    <header class="page-header text-center">
      <h1 class="page-title">Centres à proximité</h1>
    </header>

    <div id="galleryContainer" class="clearfix withSpaces col-4">
      <div class="galleryItem identity">
        <article class="portfolio-item">
          <div class="portfolio-thumbnail">
            <a href="04-pluto-portfolio-single.html"><img src="/images/content/related-01.jpg" alt=" "></a>
            <a href="04-pluto-portfolio-single.html" class="overlay-img"><span class="overlay-ico"><i class="fa fa-plus"></i></span></a>
          </div>
          <div class="entry-meta">
            <span class="cat-links"><a href="#">Identity</a>, <a href="#">Web</a></span>
          </div>
          <h4 class="entry-title"><a href="04-pluto-portfolio-single.html">Project name goes here</a></h4>
        </article>
        <!-- / portfolio-item -->
      </div>
      <div class="galleryItem web">
        <article class="portfolio-item">
          <div class="portfolio-thumbnail">
            <a href="04-pluto-portfolio-single.html"><img src="/images/content/related-02.jpg" alt=" "></a>
            <a href="04-pluto-portfolio-single.html" class="overlay-img"><span class="overlay-ico"><i class="fa fa-plus"></i></span></a>
          </div>
          <div class="entry-meta">
            <span class="cat-links"><a href="#">Identity</a>, <a href="#">Web</a></span>
          </div>
          <h4 class="entry-title"><a href="04-pluto-portfolio-single.html">Project name goes here</a></h4>
        </article>
        <!-- / portfolio-item -->
      </div>
      <div class="galleryItem print">
        <article class="portfolio-item">
          <div class="portfolio-thumbnail">
            <a href="04-pluto-portfolio-single.html"><img src="/images/content/related-03.jpg" alt=" "></a>
            <a href="04-pluto-portfolio-single.html" class="overlay-img"><span class="overlay-ico"><i class="fa fa-plus"></i></span></a>
          </div>
          <div class="entry-meta">
            <span class="cat-links"><a href="#">Identity</a>, <a href="#">Web</a></span>
          </div>
          <h4 class="entry-title"><a href="04-pluto-portfolio-single.html">Project name goes here</a></h4>
        </article>
        <!-- / portfolio-item -->
      </div>
      <div class="galleryItem identity web">
        <article class="portfolio-item">
          <div class="portfolio-thumbnail">
            <a href="04-pluto-portfolio-single.html"><img src="/images/content/related-04.jpg" alt=" "></a>
            <a href="04-pluto-portfolio-single.html" class="overlay-img"><span class="overlay-ico"><i class="fa fa-plus"></i></span></a>
          </div>
          <div class="entry-meta">
            <span class="cat-links"><a href="#">Identity</a>, <a href="#">Web</a></span>
          </div>
          <h4 class="entry-title"><a href="04-pluto-portfolio-single.html">Project name goes here</a></h4>
        </article>
        <!-- / portfolio-item -->
      </div>


    </div>
    <!-- / galleryContainer -->


  </div>
</section>
<!-- / section -->
