  <section class="flexslider std-slider" data-height="560" data-loop="true" data-smooth="false" data-slideshow="true" data-speed="15000" data-animspeed="550" data-controls="true" data-dircontrols="true">
    <ul class="slides">
      <li data-bg="/images/content/home-v1-slider-01.jpg">
        <div class="container">
          <div class="inner">
            <div class="row">
              <div class="col-md-6 animated" data-fx="fadeIn">
                <h2>Détruire la cellulite</h2>
                <p>Saviez-vous qu'une 1/2 heure d'aquabiking équivaut à une heure de fitness avec 3 fois plus de calories brûlées ?</p>
                <a href="/centres" class="btn btn-primary btn-lg">Trouver un centre</a> <a href="/aquabiking" class="btn btn-default btn-lg">Les bienfaits</a> </div>
              <div class="col-md-6"></div>
            </div>
          </div>
        </div>
      </li>
      <li data-bg="/images/content/home-v2-slider-01.jpg">
        <div class="container">
          <div class="inner">
            <div class="text-center animated" data-fx="fadeIn">
              <h2 class="page-title">D&eacute;couvrez</h2>
              <h2>LE NOUVEL AQUAVELO &Agrave; NICE</h2>
              <a href="/centres/Nice" class="btn btn-default btn-lg">R&eacute;server en ligne</a> </div>
          </div>
        </div>
      </li>
    </ul>
  </section>
  <!-- / flexslider -->