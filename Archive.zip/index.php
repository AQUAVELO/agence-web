<?
$settings = '';
$settings['dbhost'] = "localhost";
$settings['dbname'] = "alesiaminceur";
$settings['dbusername'] = "web_aquavelo";
$settings['dbpassword'] = "Amh4d0%5";

$settings['mjusername'] = "62fd2c32eb3cb16f4ff77cb287a7a5d0";
$settings['mjpassword'] = "38f730627afbf98038f4e1696200f902";
$settings['mjfrom'] = "contact@ritueldessens.com";
?>
<?
try
{
	$database = new PDO("mysql:host=".$settings['dbhost'].";dbname=".$settings['dbname'].";charset=utf8", $settings['dbusername'], $settings['dbpassword'],
               array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'"));
}
catch(Exception $error)
{
        die('Error : '.$error->getMessage());
}
?>
<?
#include
if(isset($_GET['p']) && is_file('_'.strip_tags($_GET['p']).'.php')) $page = strip_tags($_GET['p']); else $page = 'home'; 

#nav
$centers_list = $database->prepare('SELECT * FROM am_centers WHERE online = ? AND aquavelo = ? ORDER BY city ASC');
$centers_list->execute(array(1, 1));

#home
if($page == "home") {
	
$centers_last = $database->prepare('SELECT * FROM am_centers WHERE online = ? AND aquavelo = ? ORDER BY id DESC');
$centers_last->execute(array(1, 1));

}


#page
if($page == "page" && isset($_GET['city'])) {
	$city = strip_tags($_GET['city']);
	$center = $database->prepare('SELECT id FROM am_centers WHERE city = ? AND online = ? AND aquavelo = ?');
	$center->execute(array($city, 1, 1));
	$secure = $center->rowCount();
	if($secure != 0) {
	$center = $database->prepare('SELECT * FROM am_centers WHERE city = ? AND online = ? AND aquavelo = ?');
	$center->execute(array($city, 1, 1));
	$row_center = $center->fetch();
	$region = $database->prepare('SELECT nom FROM regions WHERE id = ?');
	$region->execute(array($row_center['region']));
	$row_region = $region->fetch();
	$region = $row_region['nom'];
	$department = $database->prepare('SELECT nom FROM departements WHERE id = ?');
	$department->execute(array($row_center['department']));
	$row_department = $department->fetch();
	$department = $row_department['nom'];
	$title = "$city - Centre d'amincissement pour homme en $department ";
	} else {
	header('location: ./');
	}
}
?>
<!DOCTYPE html>
<!--[if IE 8]>
<html class="no-js lt-ie9" lang="fr"> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="fr">
<!--<![endif]-->

<head>
<meta charset="UTF-8">
<meta name="description" content="Cours d'aquabiking collectif en piscine animés par un coach sportif diplômé. Éliminez votre cellulite en pédalant dans l'eau et brûlez trois plus de calories.">
<meta name="viewport" content="user-scalable=no, width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
<title>Aquabiking collectif en piscine | Aquavelo</title>
<link rel="stylesheet" type="text/css" href="/css/animate.css">
<link rel="stylesheet" type="text/css" href="/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="/css/style.css">
<style type="text/css">
body, td, th {
	font-family: 'Open Sans', sans-serif;
}
</style>
<script src="/js/modernizr.custom.js"></script>

<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!--[if lt IE 9]>
  <script src="/bootstrap/js/html5shiv.js"></script>
  <script src="/bootstrap/js/respond.min.js"></script>
  <![endif]-->

</head>
<body class="withAnimation">
<div id="boxedWrapper"> 
  
  <!-- navbar -->
  <nav class="navbar navbar-default navbar-static-top" role="navigation">
    <div class="container">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
        <a class="navbar-brand" href="http://aquavelo.com/"><img src="/images/content/logo.png" alt="Aquabiking collectif"></a> </div>
      <div class="navbar-collapse collapse">
        <form class="pull-right header-search" role="form" style="display:none;">
          <fieldset>
            <div class="container">
              <div class="form-group">
                <input type="text" class="form-control" placeholder="Type to search...">
              </div>
              <button type="submit"><i class="fa fa-search"></i></button>
            </div>
          </fieldset>
        </form>
        <a href="#" id="showHeaderSearch" class="hidden-xs"><i class="fa fa-search"></i></a>
        <ul class="nav navbar-nav navbar-right">
          <li<? if($p == 'home') echo' class="active"';?>> <a href="http://aquavelo.com/">Accueil</a> </li>
          <li class="dropdown<? if($p == 'aquabiking') echo' active';?>"> <a href="/aquabiking" class="dropdown-toggle" data-toggle="dropdown" data-target="#">Aquabiking</a>
            <ul class="dropdown-menu">
              <li><a href="/aquabiking">Le vélo dans l'eau</a></li>
              <li><a href="/aquabiking">Les bienfaits</a></li>
            </ul>
          </li>
          <li class="dropdown<? if($p == 'centres') echo' active';?>"> <a href="/centres" class="dropdown-toggle" data-toggle="dropdown" data-target="#">Centres</a>
            <ul class="dropdown-menu">
            
            <? while ($row_centers_list = $centers_list->fetch()) { ?>
            <li><a href="/centres/<?= $row_centers_list['city']; ?>" title="Aquabiking à <?= $row_centers_list['city']; ?>"><?= $row_centers_list['city']; ?></a></li>
            <? } ?>
              
            </ul>
          </li>
          <li<? if($p == 'concept') echo' class="active"';?>> <a href="/concept-aquabiking">Concept</a>

          </li>
          <li<? if($p == 'contact') echo' class="active"';?>><a href="/contact">Contact</a></li>
        </ul>
      </div>
    </div>
  </nav>
  <!-- / navbar -->
  <? include'_'.$page.'.php'; ?>
  
  <section class="content-area prefooter">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <article class="table-content animated" data-fx="flipInY">
            <section class="table-row">
              <div class="table-cell">
                <h1 class="widget-title">Suivez-nous</h1>
              </div>
              <div class="table-cell">
                <ul class="socialIcons bigIcons">
                  <li><a href="#" data-toggle="tooltip" title="Facebook"><i class="fa fa-facebook"></i></a></li>
                  <li><a href="#" data-toggle="tooltip" title="Twitter"><i class="fa fa-twitter"></i></a></li>
                  <li><a href="#" data-toggle="tooltip" title="Google+"><i class="fa fa-google-plus"></i></a></li>
                  <li><a href="#" data-toggle="tooltip" title="Pinterest"><i class="fa fa-pinterest"></i></a></li>
                </ul>
              </div>
            </section>
          </article>
        </div>
        <div class="col-md-6">
          <div class="newsletterForm">
            <div class="successMessage alert alert-success alert-dismissable" style="display: none">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
              Abonnement confirmé. </div>
            <div class="errorMessage alert alert-danger alert-dismissable" style="display: none">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
              Une erreur est survenue. </div>
            <form class="liveForm" role="form" action="/form/send.php" method="post" data-email-subject="Newsletter Form" data-show-errors="true" data-hide-form="true">
              <fieldset>
                <article class="table-content animated" data-fx="flipInY">
                  <section class="table-row">
                    <div class="table-cell">
                      <h1 class="widget-title">Recevoir la newsletter</h1>
                    </div>
                    <div class="table-cell">
                      <label class="sr-only">Adresse e-mail</label>
                      <input type="email" name="field[]" class="form-control" placeholder="Adresse e-mail">
                    </div>
                    <div class="table-cell">
                      <input type="submit" class="btn btn-primary" value="S'abonner">
                    </div>
                  </section>
                </article>
              </fieldset>
            </form>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- section -->
  
  <footer>
    <div class="container mainfooter">
      <div class="row">
        <aside class="col-md-3 widget"> <img src="/images/content/logo-footer.png" alt=" "> <br>
          <br>
          <p class="darker">Aquabiking collectif en piscine</p>
          <p class="darker">&copy; 2014</p>
        </aside>
        <aside class="col-md-3 widget">
          <h1 class="widget-title">Contactez-nous</h1>
          <a href="mailto:hello@example.com" class="larger">info@aquavelo.com</a>
          <p> 46, Boulevard de l'H&ocirc;pital<br>
            75013, Paris </p>
          <p> T&eacute;l.: +33 (0)6 27 50 33 08 </p>
        </aside>
        <aside class="col-md-3 widget">
          <h1 class="widget-title">Tweets r&eacute;cents</h1>
          <div class="tweets_display" data-limit="1"></div>
        </aside>
        <aside class="col-md-3 widget">
          <h1 class="widget-title">Flux de photo</h1>
          <div class="flickr_badge">
            <div class="flickr_badge_image"> <a href="#"><img src="/images/content/flickr_image1.jpg" alt=""></a> </div>
            <div class="flickr_badge_image"> <a href="#"><img src="/images/content/flickr_image2.jpg" alt=""></a> </div>
            <div class="flickr_badge_image"> <a href="#"><img src="/images/content/flickr_image3.jpg" alt=""></a> </div>
          </div>
        </aside>
      </div>
    </div>
  </footer>
</div>
<!-- boxedWrapper --> 

<a href="#" id="toTop"><i class="fa fa-angle-up"></i></a> 
<script src="/js/jquery.min.js"></script> 
<script src="/bootstrap/js/bootstrap.min.js"></script> 
<script src="/js/detectmobilebrowser.js"></script> 
<script src="/js/gmap3.min.js"></script> 
<script src="/js/jquery.appear.js"></script> 
<script src="/js/jquery.isotope.min.js"></script> 
<script src="/js/jquery.ba-bbq.min.js"></script> 
<script src="/js/jquery.countTo.js"></script> 
<script src="/js/jquery.fitvids.js"></script> 
<script src="/js/jquery.flexslider-min.js"></script> 
<script src="/js/jquery.magnific-popup.min.js"></script> 
<script src="/js/jquery.mb.YTPlayer.js"></script> 
<script src="/js/jquery.placeholder.min.js"></script> 
<script src="/js/retina-1.1.0.min.js"></script> 
<script src="/js/timeline/js/storyjs-embed.js"></script> 
<script src="/form/js/form.js"></script> 
<!--<script src="/twitter/js/jquery.tweet.js"></script> -->
<script src="/js/main.js"></script>
</body>
</html>