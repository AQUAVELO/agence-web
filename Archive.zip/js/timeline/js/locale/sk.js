/*
    TimelineJS - ver. 2.29.0 - 2014-01-22
    Copyright (c) 2012-2013 Northwestern University
    a project of the Northwestern University Knight Lab, originally created by Zach Wise
    https://github.com/NUKnightLab/TimelineJS
    This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
    If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
*/
/* Slovak LANGUAGE 
================================================== */typeof VMM!="undefined"&&(VMM.Language={lang:"sk",api:{wikipedia:"sk"},date:{month:["Janu&#225;r","Febru&#225;r","Marec","Apr&#237;l","M&#225;j","J&#250;n","J&#250;l","August","September","Okt&#243;ber","November","December"],month_abbr:["Jan.","Feb.","Marec","Apr&#237;l","M&#225;j","J&#250;n","J&#250;l","Aug.","Sept.","Okt.","Nov.","Dec."],day:["Nede&#318;a","Pondelok","Utorok","Streda","&#352;tvrtok","Piatok","Sobota"],day_abbr:["Ned.","Pon.","Uto.","Str.","&#352;tv.","Pia.","Sob."]},dateformats:{year:"yyyy",month_short:"mmm",month:"mmmm yyyy",full_short:"mmm d",full:"d. mmmm',' yyyy",time_short:"h:MM:ss TT",time_no_seconds_short:"h:MM TT",time_no_seconds_small_date:"h:MM TT'<br/><small>'mmmm d',' yyyy'</small>'",full_long:"mmm d',' yyyy 'at' hh:MM TT",full_long_small_date:"hh:MM TT'<br/><small>mmm d',' yyyy'</small>'"},messages:{loading_timeline:"Na&#269;&#237;tam &#269;asov&#250; os... ",return_to_title:"Sp&#228;&#357; na &#250;vod",expand_timeline:"Zv&#228;&#269;&#353;i&#357; &#269;asov&#250; os",contract_timeline:"Zmen&#353;i&#357; &#269;asov&#250; os",wikipedia:"Z Wikipedie, encyklop&#233;die zadarmo",loading_content:"Na&#269;&#237;tam obsah",loading:"Na&#269;&#237;tanie"}});